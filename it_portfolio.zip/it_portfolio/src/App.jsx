import React from "react";
export default function App(){
  return (
    <div className="app">
      <header className="hero small">
        <div className="container">
          <div className="logo">Abdul Rehman</div>
          <nav className="nav"><a>About</a><a>Projects</a><a>Contact</a></nav>
        </div>
      </header>
      <main className="container">
        <section className="lead">
          <h1>Server Admin & IT Support</h1>
          <p>Linux, virtualization, monitoring, backups and security hardening.</p>
        </section>
        <section className="projects">
          <div className="card"><h3>Prometheus Monitoring</h3><p>Setup and dashboards</p></div>
          <div className="card"><h3>Server Migration</h3><p>Zero-downtime migration plan</p></div>
        </section>
      </main>
      <footer className="footer container">© 2025 Abdul Rehman — <a href="#">GitHub</a></footer>
    </div>
  );
}