# IT Portfolio - React Dark Template

Personal portfolio for a server admin / IT professional.

Run:

```bash
npm install
npm run dev
```

Customize `src/App.jsx` and `src/index.css` to change content and styles.
